from flask import Flask, render_template, request, redirect, session
import os
import sqlite3
import cv2
from datetime import datetime

app = Flask(__name__)
app.secret_key = "secretkey"

# ---------------- DATABASE INIT ----------------
def init_db():
    conn = sqlite3.connect('attendance.db')
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS students (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT,
                        roll TEXT
                    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS attendance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT,
                        date TEXT,
                        time TEXT
                    )''')

    conn.commit()
    conn.close()

init_db()

# ---------------- LOGIN PAGE ----------------
@app.route('/')
def home():
    return render_template('login.html')


# ---------------- CHECK PASSWORD ----------------
@app.route('/check', methods=['POST'])
def check():
    password = request.form.get('password')

    # 🔐 PASSWORD IS 12345
    if password == "12345":
        session['user'] = "admin"
        return redirect('/dashboard')
    else:
        return render_template("login.html", error="Wrong Password! Try Again")


# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/')
    return render_template('dashboard.html')


# ---------------- ADD STUDENT PAGE ----------------
@app.route('/add_student')
def add_student():
    if 'user' not in session:
        return redirect('/')
    return render_template('register_camera.html')


# ---------------- CAPTURE STUDENT IMAGES ----------------
@app.route('/capture', methods=['POST'])
def capture():
    if 'user' not in session:
        return redirect('/')

    name = request.form['name']
    roll = request.form['roll']

    conn = sqlite3.connect('attendance.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO students (name, roll) VALUES (?, ?)", (name, roll))
    conn.commit()
    conn.close()

    folder_path = f"static/dataset/{name}"
    os.makedirs(folder_path, exist_ok=True)

    cam = cv2.VideoCapture(0)
    count = 0

    while True:
        ret, frame = cam.read()
        if not ret:
            break

        cv2.imshow("Capturing Images - Look at Camera", frame)
        cv2.imwrite(f"{folder_path}/{count}.jpg", frame)
        count += 1

        if count >= 25:
            break

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()

    # Auto Train
    os.system('python train.py')

    return redirect('/dashboard')


# ---------------- START ATTENDANCE ----------------
@app.route('/recognize')
def recognize():
    if 'user' not in session:
        return redirect('/')

    os.system('python face_recognize.py')
    return redirect('/dashboard')


# ---------------- VIEW ATTENDANCE ----------------
@app.route('/attendance')
def attendance():
    if 'user' not in session:
        return redirect('/')

    conn = sqlite3.connect('attendance.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name, date, time FROM attendance ORDER BY id DESC")
    data = cursor.fetchall()
    conn.close()

    return render_template('attendance.html', data=data)


# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')


# ---------------- RUN ----------------
if __name__ == '__main__':
    app.run(debug=True)